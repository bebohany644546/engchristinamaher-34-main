
# Sound Files
Please add the following sound files to the public directory for the attendance system:

- attendance-present.mp3 - Sound that plays when marking a student as present
- attendance-absent.mp3 - Sound that plays when marking a student as absent
- scan-success.mp3 - Sound that plays when successfully scanning a QR code

These sound files should be short audio clips (1-2 seconds) that provide audio feedback for these actions.
