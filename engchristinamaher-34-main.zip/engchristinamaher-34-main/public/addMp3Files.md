
# Sound Files
Place the following sound files in this directory:
- logout.mp3 (for playing when logging out)
- attendance-present.mp3 (for playing when marking attendance as present)
- attendance-absent.mp3 (for playing when marking attendance as absent)
- scan-success.mp3 (for playing when scanning a QR code or confirming an action)

Note: These files were mentioned in the code but weren't found when attempting to play them.
